//
//  TwittUtil.h
//  StreamTwitt
//
//  Created by Suman Chatterjee on 17/12/2014.
//  Copyright (c) 2014 Suman Chatterjee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TwittUtil : NSObject

+ (BOOL)isEmptyString:(NSString*)string;


@end
